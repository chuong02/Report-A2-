//chuong trinh test cam bien

#include "contiki.h"
#include "dev/i2c.h"
#include "dev/gpio.h"
#include "sys/etimer.h"
#include "clock.h"
#include "board.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ------------ I2C addresses ------------ */
#define OLED_ADDR     0x3C   /* SSD1306 */
#define TSL2561_ADDR  0x39   /* GY-2561 TSL2561 */
#define HDC1080_ADDR  0x40   /* GY-213V-HDC1080 */
#define BMP180_ADDR   0x77   /* GY-68 BMP180 */

/* ------------ Helpers cho I2C ------------ */

static uint8_t
i2c_write8(uint8_t addr, uint8_t reg, uint8_t val)
{
  uint8_t buf[2];
  buf[0] = reg;
  buf[1] = val;
  return i2c_burst_send(addr, buf, 2);
}

static uint8_t
i2c_write16(uint8_t addr, uint8_t reg, uint16_t val)
{
  uint8_t buf[3];
  buf[0] = reg;
  buf[1] = (uint8_t)(val >> 8);
  buf[2] = (uint8_t)(val & 0xFF);
  return i2c_burst_send(addr, buf, 3);
}

static uint8_t
i2c_read(uint8_t addr, uint8_t reg, uint8_t *buf, uint8_t len)
{
  if(i2c_single_send(addr, reg) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }
  clock_delay_usec(50);
  return i2c_burst_receive(addr, buf, len);
}

/* ------------ Font 5x7 ( & %) ------------ */
typedef struct {
  char c;
  uint8_t col[5];
} glyph_t;

/*
 * Font 
 * , ., :, -, space, A,C,H,L,P,R,T,U,X,%.
 */
static const glyph_t font5x7[] = {
  { ' ', {0x00,0x00,0x00,0x00,0x00} },        // space
  { '0', {0x3E,0x51,0x49,0x45,0x3E} },
  { '1', {0x00,0x42,0x7F,0x40,0x00} },
  { '2', {0x42,0x61,0x51,0x49,0x46} },
  { '3', {0x21,0x41,0x45,0x4B,0x31} },
  { '4', {0x18,0x14,0x12,0x7F,0x10} },
  { '5', {0x27,0x45,0x45,0x45,0x39} },
  { '6', {0x3C,0x4A,0x49,0x49,0x30} },
  { '7', {0x01,0x71,0x09,0x05,0x03} },
  { '8', {0x36,0x49,0x49,0x49,0x36} },
  { '9', {0x06,0x49,0x49,0x29,0x1E} },
  { '.', {0x00,0x60,0x60,0x00,0x00} },
  { ':', {0x00,0x36,0x36,0x00,0x00} },
  { '-', {0x08,0x08,0x08,0x08,0x08} },
  { '%', {0x23,0x13,0x08,0x64,0x62} },        // %
  { 'A', {0x7E,0x11,0x11,0x11,0x7E} },        // A
  { 'C', {0x3E,0x41,0x41,0x41,0x22} },        // C
  { 'H', {0x7F,0x08,0x08,0x08,0x7F} },        // H
  { 'L', {0x7F,0x40,0x40,0x40,0x40} },        // L
  { 'P', {0x7F,0x09,0x09,0x09,0x06} },        // P
  { 'R', {0x7F,0x09,0x19,0x29,0x46} },        // R
  { 'T', {0x01,0x01,0x7F,0x01,0x01} },        // T
  { 'U', {0x3F,0x40,0x40,0x40,0x3F} },        // U
  { 'X', {0x63,0x14,0x08,0x14,0x63} },        // X
};

#define FONT_LEN (sizeof(font5x7) / sizeof(font5x7[0]))
#define OLED_TEXT_COLS 21   /* 21 ký tự * 6 pixel = 126 cột */

/* Tra glyph cho 1 ký tự (không có trả về space) */
static const uint8_t *
glyph_for(char c)
{
  uint8_t i;
  for(i = 0; i < FONT_LEN; i++) {
    if(font5x7[i].c == c) {
      return font5x7[i].col;
    }
  }
  return font5x7[0].col; /* space */
}

/* ------------ OLED SSD1306 ------------ */

static void
oled_cmd(uint8_t cmd)
{
  uint8_t buf[2];
  buf[0] = 0x00;   /* control byte: command */
  buf[1] = cmd;
  i2c_burst_send(OLED_ADDR, buf, 2);
}

static void
oled_set_cursor(uint8_t col, uint8_t page)
{
  oled_cmd(0xB0 | (page & 0x07));              /* page */
  oled_cmd(0x00 | (col & 0x0F));               /* lower column */
  oled_cmd(0x10 | ((col >> 4) & 0x0F));        /* higher column */
}

static void
oled_draw_char(char c)
{
  uint8_t buf[7];
  const uint8_t *g = glyph_for(c);
  uint8_t i;

  buf[0] = 0x40;      /* control byte: data */
  for(i = 0; i < 5; i++) {
    buf[1 + i] = g[i];
  }
  buf[6] = 0x00;      

  i2c_burst_send(OLED_ADDR, buf, 7);
}

static void
oled_print_line(uint8_t line, const char *s)
{
  uint8_t count = 0;
  oled_set_cursor(0, line);
  while(count < OLED_TEXT_COLS) {
    char c = (*s != '\0') ? *s++ : ' ';
    oled_draw_char(c);
    count++;
  }
}

static void
oled_clear(void)
{
  uint8_t page;
  uint8_t buf[17];
  uint8_t col;

  buf[0] = 0x40;
  for(col = 1; col < sizeof(buf); col++) {
    buf[col] = 0x00;
  }

  for(page = 0; page < 8; page++) {
    uint8_t x = 0;
    oled_set_cursor(0, page);
    while(x < 128) {
      uint8_t chunk = (128 - x > 16) ? 16 : (128 - x);
      i2c_burst_send(OLED_ADDR, buf, 1 + chunk);
      x += chunk;
    }
  }
}

static void
oled_init(void)
{
  /* SSD1306 128x64 I2C */
  static const uint8_t init_seq[] = {
    0xAE,       /* display off */
    0xD5, 0x80, /* clock div */
    0xA8, 0x3F, /* multiplex 1/64 */
    0xD3, 0x00, /* display offset */
    0x40,       /* start line = 0 */
    0x8D, 0x14, /* charge pump on */
    0x20, 0x00, /* memory mode: horizontal */
    0xA1,       /* segment remap */
    0xC8,       /* COM scan dec */
    0xDA, 0x12, /* COM pins config */
    0x81, 0xCF, /* contrast */
    0xD9, 0xF1, /* pre-charge */
    0xDB, 0x40, /* VCOM detect */
    0xA4,       /* resume RAM content */
    0xA6,       /* normal display */
    0x2E,       /* deactivate scroll */
    0xAF        /* display ON */
  };

  uint8_t i = 0;
  while(i < sizeof(init_seq)) {
    oled_cmd(init_seq[i++]);
  }
  oled_clear();
}

/* ------------ TSL2561 (GY-2561) ------------ */

static void
tsl2561_init(void)
{
  /* Power on: CONTROL register = 0x03, bit CMD = 1 */
  i2c_write8(TSL2561_ADDR, 0x80 | 0x00, 0x03);
  /* Timing: integration 402ms, gain 1x (0x02) */
  i2c_write8(TSL2561_ADDR, 0x80 | 0x01, 0x02);
}

static uint16_t
tsl2561_read_ch0(void)
{
  uint8_t buf[2];
  if(i2c_read(TSL2561_ADDR, 0x80 | 0x0C, buf, 2) != I2C_MASTER_ERR_NONE) {
    return 0xFFFF;
  }
  return (uint16_t)((buf[1] << 8) | buf[0]);
}

/* ------------ HDC1080 (GY-213V-HDC1080) ------------ */
/* T(°C) = raw * 165 / 2^16 - 40, RH(%) = raw * 100 / 2^16 */

static void
hdc1080_init(void)
{
  /* Config: đo cả T & RH, 14-bit, heater off (0x1000) */
  i2c_write16(HDC1080_ADDR, 0x02, 0x1000);
}

/* Debug: đọc Manufacturer ID & Device ID  */
static void
hdc1080_check_id(void)
{
  uint8_t buf[2];
  uint16_t mid, did;

  if(i2c_read(HDC1080_ADDR, 0xFE, buf, 2) == I2C_MASTER_ERR_NONE) {
    mid = (uint16_t)((buf[0] << 8) | buf[1]);
    printf("HDC1080 MID = 0x%04X (expect 0x5449)\n", mid);
  } else {
    printf("HDC1080 read MID error\n");
  }

  if(i2c_read(HDC1080_ADDR, 0xFF, buf, 2) == I2C_MASTER_ERR_NONE) {
    did = (uint16_t)((buf[0] << 8) | buf[1]);
    printf("HDC1080 DID = 0x%04X (expect 0x1050)\n", did);
  } else {
    printf("HDC1080 read DID error\n");
  }
}

static uint8_t
hdc1080_read(int16_t *t_x10, uint16_t *rh_x10)
{
  uint8_t buf[4];

  /* pointer = 0x00  trigger đo T+RH */
  if(i2c_single_send(HDC1080_ADDR, 0x00) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }

  /*  ~6.5ms/14bit mỗi kênh, chờ 20ms  */
  clock_delay_usec(20000);

  if(i2c_burst_receive(HDC1080_ADDR, buf, 4) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }

  uint16_t raw_t  = (uint16_t)((buf[0] << 8) | buf[1]);
  uint16_t raw_rh = (uint16_t)((buf[2] << 8) | buf[3]);

  int32_t t = ((int32_t)raw_t * 1650) / 65536 - 400;   /* 0.1 °C */
  int32_t h = ((int32_t)raw_rh * 1000) / 65536;        /* 0.1 %RH */

  *t_x10  = (int16_t)t;
  *rh_x10 = (uint16_t)h;

  return I2C_MASTER_ERR_NONE;
}

/* ------------ BMP180 (GY-68) ------------ */
/*  datasheet BMP180, OSS = 0 */

static int16_t AC1, AC2, AC3, B1, B2, MB, MC, MD;
static uint16_t AC4, AC5, AC6;
static uint8_t bmp180_calib_ok = 0;

static uint8_t
bmp180_read_calib(void)
{
  uint8_t buf[22];
  if(i2c_read(BMP180_ADDR, 0xAA, buf, 22) != I2C_MASTER_ERR_NONE) {
    return 1;
  }

  AC1 = (int16_t)((buf[0] << 8) | buf[1]);
  AC2 = (int16_t)((buf[2] << 8) | buf[3]);
  AC3 = (int16_t)((buf[4] << 8) | buf[5]);
  AC4 = (uint16_t)((buf[6] << 8)  | buf[7]);
  AC5 = (uint16_t)((buf[8] << 8)  | buf[9]);
  AC6 = (uint16_t)((buf[10] << 8) | buf[11]);
  B1  = (int16_t)((buf[12] << 8) | buf[13]);
  B2  = (int16_t)((buf[14] << 8) | buf[15]);
  MB  = (int16_t)((buf[16] << 8) | buf[17]);
  MC  = (int16_t)((buf[18] << 8) | buf[19]);
  MD  = (int16_t)((buf[20] << 8) | buf[21]);

  bmp180_calib_ok = 1;
  return 0;
}

static uint8_t
bmp180_read(int16_t *t_x10, int32_t *p_pa)
{
  const uint8_t OSS = 0;
  uint8_t buf[3];
  int32_t UT, UP;
  int32_t X1, X2, X3, B3, B5, B6, p;
  uint32_t B4, B7;

  if(!bmp180_calib_ok && bmp180_read_calib()) {
    return 1;
  }

  /* --- Nhiệt độ --- */
  if(i2c_write8(BMP180_ADDR, 0xF4, 0x2E) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }
  clock_delay_usec(5000);

  if(i2c_read(BMP180_ADDR, 0xF6, buf, 2) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }
  UT = (int32_t)((buf[0] << 8) | buf[1]);

  X1 = ((UT - (int32_t)AC6) * (int32_t)AC5) >> 15;
  X2 = ((int32_t)MC << 11) / (X1 + MD);
  B5 = X1 + X2;
  *t_x10 = (int16_t)((B5 + 8) >> 4);  /* 0.1 °C */

  /* --- Áp suất --- */
  if(i2c_write8(BMP180_ADDR, 0xF4, (uint8_t)(0x34 + (OSS << 6))) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }
  clock_delay_usec(8000);

  if(i2c_read(BMP180_ADDR, 0xF6, buf, 3) != I2C_MASTER_ERR_NONE) {
    return i2c_master_error();
  }

  UP = (((int32_t)buf[0] << 16) | ((int32_t)buf[1] << 8) | buf[2]) >> (8 - OSS);

  B6 = B5 - 4000;
  X1 = (B2 * ((B6 * B6) >> 12)) >> 11;
  X2 = (AC2 * B6) >> 11;
  X3 = X1 + X2;
  B3 = ((((int32_t)AC1 * 4 + X3) << OSS) + 2) >> 2;
  X1 = (AC3 * B6) >> 13;
  X2 = (B1 * ((B6 * B6) >> 12)) >> 16;
  X3 = ((X1 + X2) + 2) >> 2;
  B4 = (uint32_t)(AC4) * (uint32_t)(X3 + 32768) >> 15;
  B7 = ((uint32_t)UP - (uint32_t)B3) * (uint32_t)(50000 >> OSS);

  if(B7 < 0x80000000UL) {
    p = (int32_t)((B7 << 1) / B4);
  } else {
    p = (int32_t)((B7 / B4) << 1);
  }

  X1 = (p >> 8) * (p >> 8);
  X1 = (X1 * 3038) >> 16;
  X2 = (-7357 * p) >> 16;
  p = p + ((X1 + X2 + 3791) >> 4);

  *p_pa = p;  /* Pascal */

  return I2C_MASTER_ERR_NONE;
}

/* ------------ Main Contiki process ------------ */

PROCESS(i2c_sensors_demo_process, "I2C sensors + OLED demo");
AUTOSTART_PROCESSES(&i2c_sensors_demo_process);

PROCESS_THREAD(i2c_sensors_demo_process, ev, data)
{
  static struct etimer timer;
  static int16_t t_hdc_x10, t_bmp_x10;
  static uint16_t rh_x10;
  static uint16_t light_raw;
  static int32_t p_pa;
  char line[32];

  PROCESS_BEGIN();

  /* Init I2C với SDA = PB4, SCL = PB3 */
  i2c_init(GPIO_B_NUM, 4,   /* SDA = PB4 */
           GPIO_B_NUM, 3,   /* SCL = PB3 */
           I2C_SCL_NORMAL_BUS_SPEED);

  oled_init();
  tsl2561_init();
  hdc1080_init();
  bmp180_read_calib();
  hdc1080_check_id();   /* In MID & DID ra UART  */

  printf("=== I2C demo cc2538dk ===\n");
  printf("Line1: T,RH (C / %%)\n");
  printf("Line2: P (hPa approx)\n");
  printf("Line3: L (light raw)\n");

  etimer_set(&timer, CLOCK_SECOND);

  while(1) {
    uint8_t hdc_err, bmp_err;

    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&timer));
    etimer_reset(&timer);

    light_raw = tsl2561_read_ch0();
    hdc_err = hdc1080_read(&t_hdc_x10, &rh_x10);
    bmp_err = bmp180_read(&t_bmp_x10, &p_pa);

    /* In ra UART cho debug */
    printf("LIGHT raw=%u | ", (unsigned)light_raw);

    if(hdc_err == I2C_MASTER_ERR_NONE) {
      printf("HDC1080: T=%d.%d C  RH=%u.%u %% | ",
             t_hdc_x10 / 10, abs(t_hdc_x10 % 10),
             rh_x10 / 10, rh_x10 % 10);
    } else {
      printf("HDC1080 error=%u | ", (unsigned)hdc_err);
    }

    if(bmp_err == I2C_MASTER_ERR_NONE) {
      printf("BMP180: T=%d.%d C  P=%ld Pa\n",
             t_bmp_x10 / 10, abs(t_bmp_x10 % 10),
             (long)p_pa);
    } else {
      printf("BMP180 error=%u\n", (unsigned)bmp_err);
    }

    /* ------- OLED ------- */

    /* Dòng 1: T:xx.xC H:yy.y% */
if(hdc_err == I2C_MASTER_ERR_NONE) {
  snprintf(line, sizeof(line), "T:%2d.%1dC H:%2u.%1u%%",
           t_hdc_x10 / 10, abs(t_hdc_x10 % 10),
           rh_x10 / 10, rh_x10 % 10);
} else {
  snprintf(line, sizeof(line), "T:--.-C H:--.-%%");
}
oled_print_line(0, line);


    /* Dòng 2: P:pppp.p hPA  (đổi sang 0.1 hPa) */
/* Dòng 2: P:pppp.p HPA  (đổi sang 0.1 hPa) */
if(bmp_err == I2C_MASTER_ERR_NONE) {
  long p_hpa_x10 = p_pa / 10;   /* Pa -> 0.1 hPa */

  snprintf(line, sizeof(line), "P:%4ld.%1ldHPA",
           p_hpa_x10 / 10,          /* phần nguyên hPa  */
           labs(p_hpa_x10 % 10));   /* 1 số lẻ 0.1 hPa */
} else {
  snprintf(line, sizeof(line), "P:----.-HPA");
}
oled_print_line(1, line);


    /* Dòng 3: LUX:llllLX (raw) */
snprintf(line, sizeof(line), "LUX:%5uLX", (unsigned)light_raw);
oled_print_line(2, line);

  }

  PROCESS_END();
}
