/*
 * Copyright (c) 2006, Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

/**
 * \file
 *         A very simple Contiki application showing how Contiki programs look
 * \author
 *         Adam Dunkels <adam@sics.se>
 */



//Code nguyen mau
/*
#include "contiki.h"
#include "dev/leds.h"

#include <stdio.h> //For printf() 

static	struct	etimer	et;
static uint8_t i;



PROCESS(hello_world_process, "Hello world process");
AUTOSTART_PROCESSES(&hello_world_process);

PROCESS_THREAD(hello_world_process, ev, data)  { 
	PROCESS_BEGIN();

	etimer_set(&et, CLOCK_SECOND*2);
	i =0;

	while(1) {
    	PROCESS_YIELD();
    	if (ev==PROCESS_EVENT_TIMER) {
  			printf("TIMER fired: i=%d \n",i);
			i++; 			
 			leds_toggle(LEDS_BLUE);
 			//leds_toggle(LEDS_GREEN); 	
 			leds_toggle(LEDS_GREEN); 		
    		etimer_restart(&et);
	   	}
  	}	

  PROCESS_END();
}

*/


// code test cac port C,B


#include "contiki.h"
#include "dev/gpio.h"
#include "dev/ioc.h"
#include <stdio.h>

static struct etimer et;

static void
gpio_toggle(uint32_t port, uint8_t pinmask)
{
  if(GPIO_READ_PIN(port, pinmask)) {
    GPIO_WRITE_PIN(port, pinmask, 0x00);
  } else {
    GPIO_WRITE_PIN(port, pinmask, 0xFF);
  }
}

PROCESS(led_custom_process, "Custom LED blinking");
AUTOSTART_PROCESSES(&led_custom_process);

PROCESS_THREAD(led_custom_process, ev, data)
{
  PROCESS_BEGIN();

  /* Đưa chân về software control + cấu hình output */
  /* PC0, PC1 */
  GPIO_SOFTWARE_CONTROL(GPIO_C_BASE, (1 << 0));
  GPIO_SET_OUTPUT     (GPIO_C_BASE, (1 << 0));

  GPIO_SOFTWARE_CONTROL(GPIO_C_BASE, (1 << 1));
  GPIO_SET_OUTPUT     (GPIO_C_BASE, (1 << 1));

  /* PB0, PB1 */
  GPIO_SOFTWARE_CONTROL(GPIO_B_BASE, (1 << 0));
  GPIO_SET_OUTPUT     (GPIO_B_BASE, (1 << 0));

  GPIO_SOFTWARE_CONTROL(GPIO_B_BASE, (1 << 1));
  GPIO_SET_OUTPUT     (GPIO_B_BASE, (1 << 1));

  // Tắt hết 4 LED lúc khởi động
  GPIO_WRITE_PIN(GPIO_C_BASE, (1 << 0), 0x00); // L1 OFF
  GPIO_WRITE_PIN(GPIO_C_BASE, (1 << 1), 0x00); // L2 OFF
  GPIO_WRITE_PIN(GPIO_B_BASE, (1 << 0), 0x00); // L3 OFF
  GPIO_WRITE_PIN(GPIO_B_BASE, (1 << 1), 0x00); // L4 OFF


  etimer_set(&et, CLOCK_SECOND);

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(ev == PROCESS_EVENT_TIMER);

    gpio_toggle(GPIO_C_BASE, (1 << 0));  // PC0 - L1
    gpio_toggle(GPIO_C_BASE, (1 << 1));  // PC1 - L2
    gpio_toggle(GPIO_B_BASE, (1 << 0));  // PB0 - L3
    gpio_toggle(GPIO_B_BASE, (1 << 1));  // PB1 - L4

    etimer_reset(&et);
  }

  PROCESS_END();
}

